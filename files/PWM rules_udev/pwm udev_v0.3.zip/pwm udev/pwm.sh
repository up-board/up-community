#!/bin/bash

# PWM0

echo 3413333 > /sys/class/pwm/pwmchip0/pwm0/period
echo 1706667 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle
echo 1 > /sys/class/pwm/pwmchip0/pwm0/enable


sleep 10

echo 0 > /sys/class/pwm/pwmchip0/pwm0/enable
echo 0 > /sys/class/pwm/pwmchip0/unexport

# PWM1

echo 3413333 > /sys/class/pwm/pwmchip0/pwm1/period
echo 1706667 > /sys/class/pwm/pwmchip0/pwm1/duty_cycle
echo 1 > /sys/class/pwm/pwmchip0/pwm1/enable


sleep 10

echo 0 > /sys/class/pwm/pwmchip0/pwm1/enable
echo 1 > /sys/class/pwm/pwmchip0/unexport

