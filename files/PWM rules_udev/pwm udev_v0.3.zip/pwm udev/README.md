# udev rule for pwm0/pwm1/

# Introduction
This document describes how to setup a udev rule for accessing pwm0, pwm1 device in user space

# Pre-requisites
- install upboard-extras and add groups and user to groups following the steps in the link from the [wiki](https://github.com/up-board/up-community/wiki/Ubuntu_18.04#install-upboard-extras)
- copy file 99-pwm.rules to /lib/udev/rules.d
- reboot


# Test
- Run script pwm.sh

``` ./pwm.sh```

# Expected Result
- Simple PWM script writes to pwm0/pwm1's period, duty_cycle, enable and unexport
- Accesses pwm0/pwm1/ in user space




##  Version 
0.3

## Author

* **Camillus  Teteh**


## Acknowledgments

* Hat tip to anyone whose code was used
