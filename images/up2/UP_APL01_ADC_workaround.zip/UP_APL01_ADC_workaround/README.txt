(1) Follow the link to update Ubuntu: https://github.com/up-board/up-community/wiki/Ubuntu_20.04 
(2) Replace the adc kernel module 
$ sudo cp ti-adc128s052.ko  /lib/modules/5.4.0-1-generic/kernel/drivers/iio/adc/ti-adc128s052.ko 
$ sudo update-initramfs -k 5.4.0-1-generic -c
$ sudo reboot

