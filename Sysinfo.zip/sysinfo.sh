#!/bin/bash
# Author: Nicola Lunghi <nicola.lunghi@emutex.com>
# Copyright (c) 2017 Emutex Ltd.
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

SCRIPT_VERSION="1.3"

########################################################################
# FUNCTION DEFINITION
########################################################################

# program needed to create the log
PREREQ="lshw tree"

## print message on stderr
pr_err() { printf "%s\n" "$*" >&2; }

## print log section
pr_section () {
    printf "\n>>>>>>>> %s\n\n" "${*}"
}

# execute command and add a section in the log
ex_cmd () {
    pr_section "$*"
    eval "$*"
}

# check if the script is run as root
check_root () {
    if [[ $EUID -ne 0 ]]
    then
        pr_err "This script must be run as root"
        exit 1
    fi
}

# check if all command needed are installed
check_prereq () {
    MISSING=""

    for p in $PREREQ; do
        if ! hash "$p" &>/dev/null
        then
            MISSING+="$p "
        fi
    done

    if [ "$MISSING" != "" ]
    then
        pr_err "missing packages: ${MISSING}"
        pr_err "installing it..."
        EX_CMD="apt-get update &> /dev/null && apt-get install -y ${MISSING} &> /dev/null"
        if ! eval ${EX_CMD}
        then
            pr_err "Error installing packages ${MISSING}!"
            pr_err "command that failed:"
            pr_err "${EX_CMD}"
            exit 1
        fi
        pr_err "Finished checking installed packages."
    fi
}

########################################################################
# MAIN PROGRAM
########################################################################
check_root
check_prereq

pr_section "script information"
echo "SCRIPT NAME    = sysinfo.sh"
echo "SCRIPT_VERSION = $SCRIPT_VERSION"
echo "EXECUTION_DATE = $(date -u)"

ex_cmd "uname -a"
ex_cmd "lsb_release -a"
ex_cmd "dmidecode"
ex_cmd "dmesg"
ex_cmd "lshw"
ex_cmd "lspci -v"
ex_cmd "lsusb -v"
ex_cmd "lsblk"
ex_cmd "lsmod"
ex_cmd "mount"
ex_cmd "apt list --installed"
ex_cmd "ip a"
ex_cmd "aplay -l"
ex_cmd "locale"
ex_cmd "ls -lha /dev"
ex_cmd "ls -lha /sys/class/gpio"
ex_cmd "ls -lha /sys/kernel/debug/regmap"
ex_cmd "tail -vn +1 /sys/kernel/debug/regmap/AA*/*"
ex_cmd "ls -lha /sys/kernel/debug/pinctrl"
ex_cmd "tail -vn +1 /sys/kernel/debug/pinctrl/*/{gpio-ranges,pins}"
ex_cmd "tree /sys/devices/pci0*"
ex_cmd "cat /etc/default/grub"
ex_cmd "cat /etc/apt/sources.list"
ex_cmd "tail -vn +1 /etc/apt/sources.list.d/*"
ex_cmd "python -c 'import mraa; print mraa.getVersion()'"

